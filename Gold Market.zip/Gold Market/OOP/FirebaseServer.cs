﻿using Firebase.Storage;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gold_Market.OOP
{
    class FirebaseServer
    {


        public void StartBackUp()
        {
          
        }




    }
}
